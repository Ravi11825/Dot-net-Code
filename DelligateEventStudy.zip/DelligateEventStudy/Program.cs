﻿using System;

namespace DelligateEventStudy
{
    class Program
    {
        static void Main(string[] args)
        {
            DelligateExample obj1 = new DelligateExample();
            // obj1.objMydelegate();
            //obj1.ActionDelegate();
            int i = obj1.FuncDelegate(2,3);
            Console.WriteLine(i);
            Console.WriteLine(obj1.PredicateDelegate("Sunday"));
            Console.ReadLine();
        }
    }
}
