﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DelligateEventStudy
{
    //func
    //Action for void
    //Predicate
    public delegate int ArithmeticPointer(int a ,int b);
    public delegate void MyFunctionPointer();
    class DelligateExample
    {
        public MyFunctionPointer objMydelegate;
        public ArithmeticPointer ObjArithmeticPointer;
        public Action<string,string> ActionDelegate;
        public Func<int,int,int> FuncDelegate;
        public Predicate<string> PredicateDelegate;
        
        //[modifier] delegate [return_type][delegate_name] ([parameter_list]);
        public DelligateExample()
        {
            //objMydelegate = ShowInfo;
            //objMydelegate += ShowData;
            objMydelegate += ShowColour;
            ObjArithmeticPointer = Add;
            ActionDelegate = ShowInfo;
            FuncDelegate = Add;
            PredicateDelegate = IsWeekend;
        }

        private int Add(int a,int b)
        {
            return a + b;
        }
        private void ShowData()
        {
            Console.WriteLine("showdata called");
        }

        private void ShowInfo(string info, string info1)
        {
            Console.WriteLine("ShowInfo called " + info);
        }

        private void ShowColour()
        {
            Console.WriteLine("ShowColour called");
        }

        public Boolean IsWeekend(string day)
        {
           //if(day.ToUpper() == "Sunday".ToUpper()|| day.ToUpper()== "Saturday".ToUpper())
            //{
            //    return true;
            //}
            //else
            //{
            //    return false;
            //}
            bool Retval = (day.ToUpper() == "Sunday".ToUpper() || day.ToUpper() == "Saturday".ToUpper()) ? true : false;
            return Retval;
        }
    }
}
